package com.example.qhacksteam.foodz;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    public boolean vegetarian = MainActivity.vegetarian;
    public boolean vegan = MainActivity.vegan;
    public boolean lactose = MainActivity.lactose;
    public boolean peanut = MainActivity.peanut;
    public boolean gluten = MainActivity.gluten;
    public boolean seafood = MainActivity.seafood;
    public boolean kosher = MainActivity.kosher;
    public boolean halal = MainActivity.halal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ImageView pin1 = (ImageView) findViewById(R.id.pin1);
        ImageView pin2 = (ImageView) findViewById(R.id.pin2);
        ImageView pin3 = (ImageView) findViewById(R.id.pin3);
        ImageView pin4 = (ImageView) findViewById(R.id.pin4);
        ImageView pin5 = (ImageView) findViewById(R.id.pin5);
        ImageView pin6 = (ImageView) findViewById(R.id.pin6);
        ImageView pin7 = (ImageView) findViewById(R.id.pin7);
        ImageView pin8 = (ImageView) findViewById(R.id.pin8);

        if (vegetarian)
            pin1.setVisibility(View.VISIBLE);
        else
            pin1.setVisibility(View.INVISIBLE);

        if (vegan)
            pin2.setVisibility(View.VISIBLE);
        else {
            pin2.setVisibility(View.INVISIBLE);
            pin1.setVisibility(View.INVISIBLE);
            pin3.setVisibility(View.INVISIBLE);
        }

        if (lactose)
            pin3.setVisibility(View.VISIBLE);
        else
            pin3.setVisibility(View.INVISIBLE);

        if (peanut)
            pin4.setVisibility(View.VISIBLE);
        else
            pin4.setVisibility(View.INVISIBLE);

        if (gluten)
            pin5.setVisibility(View.VISIBLE);
        else
            pin5.setVisibility(View.INVISIBLE);

        if (seafood)
            pin6.setVisibility(View.VISIBLE);
        else
            pin6.setVisibility(View.INVISIBLE);

        if (kosher)
            pin7.setVisibility(View.VISIBLE);
        else
            pin7.setVisibility(View.INVISIBLE);

        if (halal)
            pin8.setVisibility(View.VISIBLE);
        else
            pin8.setVisibility(View.INVISIBLE);
    }

}
