package com.example.qhacksteam.foodz;

import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    public boolean vegetarian = MainActivity.vegetarian;
    public boolean vegan = MainActivity.vegan;
    public boolean lactose = MainActivity.lactose;
    public boolean peanut = MainActivity.peanut;
    public boolean gluten = MainActivity.gluten;
    public boolean gluten2 = MainActivity.gluten2;
    public boolean seafood = MainActivity.seafood;
    public boolean kosher = MainActivity.kosher;
    public boolean halal = MainActivity.halal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;


        LatLng pizzaExpress = new LatLng(44.233022, -76.491203);
        Marker Pizza = mMap.addMarker(new MarkerOptions().position(pizzaExpress).title("Pizza Express"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(pizzaExpress));
        float zoomLevel = 16.0f; //This goes up to 21
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(pizzaExpress, zoomLevel));

        LatLng burger = new LatLng(44.232169, -76.486794);
        Marker Burger = mMap.addMarker(new MarkerOptions().position(burger).title("The Burger Barn"));

        LatLng shawarma = new LatLng(44.233660, -76.489803);
        Marker Shawarma = mMap.addMarker(new MarkerOptions().position(shawarma).title("Shawarma Hut"));

        LatLng peanuts = new LatLng(44.234254, -76.495160);
        Marker Peanut = mMap.addMarker(new MarkerOptions().position(peanuts).title("The Peanut Emporium"));

        LatLng bill = new LatLng(44.235013, -76.497083);
        Marker Bill = mMap.addMarker(new MarkerOptions().position(bill).title("Papa Bill's"));

        LatLng sea = new LatLng(44.232016, -76.479588);
        Marker Sea = mMap.addMarker(new MarkerOptions().position(sea).title("Sea Sweet"));

        LatLng dipster = new LatLng(44.232291, -76.492858);
        Marker Dipster = mMap.addMarker(new MarkerOptions().position(dipster).title("Dipster"));

        LatLng iceCream = new LatLng(44.227757, -76.492986);
        Marker IceCream = mMap.addMarker(new MarkerOptions().position(iceCream).title("Linda's Ice Cream"));

        LatLng sushi = new LatLng(44.229859, -76.496966);
        Marker Sushi = mMap.addMarker(new MarkerOptions().position(sushi).title("Sushi Me"));

        LatLng veggieQ = new LatLng(44.235308, -76.497451);
        Marker VeggieQ = mMap.addMarker(new MarkerOptions().position(veggieQ).title("VeggieQ"));

        if (!vegetarian){
            Burger.remove();
            Shawarma.remove();
            Sushi.remove();
        }
        if (!vegan){
            Pizza.remove();
            Burger.remove();
            Shawarma.remove();
            Sea.remove();
            IceCream.remove();
            Sushi.remove();
            Dipster.remove();
        }
        if (!lactose){
            Pizza.remove();
            Dipster.remove();
            IceCream.remove();
        }
        if (!peanut){
            Peanut.remove();
            Sea.remove();
            Dipster.remove();
            IceCream.remove();
            VeggieQ.remove();
        }
        if (!gluten || !gluten2){
            Pizza.remove();
            Shawarma.remove();
            Bill.remove();
        }
        if (!seafood){
            Bill.remove();
            Sea.remove();
            Dipster.remove();
            Sushi.remove();
        }
        if (!kosher){
            Burger.remove();
            Dipster.remove();
            VeggieQ.remove();
        }
        if (!halal){
            Burger.remove();
            Bill.remove();
            Sea.remove();
            Dipster.remove();
            VeggieQ.remove();
        }

    }
}
